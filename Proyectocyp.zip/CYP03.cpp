// CYP03.cpp : Este archivo contiene la función "main". La ejecución del programa comienza y termina ahí.
//

#include <stdio.h>

int main()
{
    int Dia, Mes, Anio;

    scanf_s("%d %d %d", &Dia, &Mes, &Anio);

    int esBisiesto = (Anio % 4 == 0 && (Anio % 100 != 0 || Anio % 400 == 0));

    Dia += 1;

    int tiene31Dias = (Mes == 1 || Mes == 3 || Mes == 5 || Mes == 7 || Mes == 8 || Mes == 10 || Mes == 12);

    if (((Mes == 2 && (esBisiesto == 0 && Dia > 28 || esBisiesto == 1 && Dia > 29)) || (tiene31Dias == 0 && Dia > 30) || (tiene31Dias == 1 && Dia > 31)))
    {
        Dia = 1;
        Mes += 1;

        if (Mes > 12) 
        {
            Mes = 1;
            Anio += 1;
        }
    }

    if (Anio == 1582 && Mes == 10 && Dia >= 5 && Dia <= 14)
    {
        Dia = 15;
    }

    printf("%2d %2d %4d", Dia, Mes, Anio);

    return 0;
}